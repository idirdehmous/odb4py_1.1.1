/* A dummy "mysql.h" header file */

/* You need to access a proper one if you want to get
   ODB to MySQL -link working */

/* Needed by ../aux/odb2mysql.c */
